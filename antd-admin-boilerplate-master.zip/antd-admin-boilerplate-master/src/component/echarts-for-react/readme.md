## 说明

https://github.com/hustcc/echarts-for-react/issues/3

因为上面这个组件暂时未做 echarts 按需加载
所以自己改了按需加载
密切关注上面组件