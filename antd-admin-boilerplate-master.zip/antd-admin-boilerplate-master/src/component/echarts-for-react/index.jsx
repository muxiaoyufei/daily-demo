import ReactEcharts from './ReactEcharts'
export default ReactEcharts