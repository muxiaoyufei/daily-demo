import FAIcon from './FAIcon'
export default FAIcon