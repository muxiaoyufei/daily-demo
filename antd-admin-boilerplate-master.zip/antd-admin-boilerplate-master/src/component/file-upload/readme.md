## 更改

- 改为执行commonUpload方式便不会清除input的值
