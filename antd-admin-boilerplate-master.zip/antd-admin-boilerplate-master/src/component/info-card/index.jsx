import InfoCard from './InfoCard'
export default InfoCard
