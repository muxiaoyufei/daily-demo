import Page from './Page.jsx'
export default Page