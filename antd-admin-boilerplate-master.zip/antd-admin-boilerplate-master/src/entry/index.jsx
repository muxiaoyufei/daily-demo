"use strict"

import React from 'react'
import ReactDOM from 'react-dom'
import  'babel-polyfill'

import App from '../framework/app/App.jsx'

ReactDOM.render((
    <App />
), document.getElementById('yt-app'))
