const GET_TASK = 'GET_TASK';
import { fromJS } from 'immutable'
import {urlLoader} from '../../../common/util/fetch.js'

function getAction(type, progressType, result, success)
{
    console.log("getAction type=", type, "progressType=", progressType, "result=", result);
    return {type,progressType, result, success}
}

function getResultCode(jsonResult)
{
    return Promise.resolve(jsonResult.jsonResult);
}

function dispatchAction(dispatch, type, progressType, success, result)
{
    console.log("slkdfjsldkfjsdlfkjsfd",type, progressType, success, result);
    dispatch(getAction(type, progressType,result, success,))
}

export function getTaskData(data)
{
    return dispatch => {

        let result = [
            {rank: 1, title: "success"},
            {rank: 2, title: "success"},
            {rank: 3, title: "success"},
            {rank: 4, title: "success"},
            {rank: 5, title: "success"},
            {rank: 6, title: "success"},
            {rank: 7, title: "success"},
            {rank: 8, title: "success"},
            {rank: 9, title: "success"},
        ],
        progressType="leftTest",
        success='xiajibace';

        dispatch(getAction(GET_TASK, progressType,success));

        let settingUrl = "https://dolphinsetting-devdebug.ntalker.com/leaveMsg/kf_1000";
        urlLoader(settingUrl,{method: "GET",headers:{token: "a2ZfMTAwMF9hZG1pbg=="}})
        .then(getResultCode)
        .then(dispatchAction.bind(null, dispatch, GET_TASK, progressType,success/* , result */))
        /* .then(finalResult => {
            progressType="rightrighteigrktightis";
            dispatch(getAction(GET_TASK, progressType, finalResult.data, success ))
        }) */
    }
}

let initialState = fromJS({
    taskData: {
        result: [],
        success: false,
        progressType: ''
    }
})

export default function getTaskDataReducer(state=initialState, action)
{
    console.log("skdfjlskdjfsldkfj",action);
    switch (action.type)
    {
        case GET_TASK : 
            
            return state.setIn(['taskData', 'result'], action.result)
                    .setIn(['taskData', 'success'], action.success)
                    .setIn(['taskData', 'progressType'], action.progressType)

        default:
            return state;
    }
}