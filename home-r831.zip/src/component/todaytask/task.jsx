import React,{Component} from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import './task.scss';
import {getTaskData} from './rudex/taskReducer'
import {Form, TreeSelect} from 'antd';

const FormItem = Form.Item, TreeNode = TreeSelect.TreeNode;

class Task extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: null
        }
    }

    componentDidMount()
    {
        this.props.getTaskData();
    }

    onChange(value)
    {
            console.log("laskdfjslakfjdlsdfkj", value);
            
            let filtValue = value.filter(item => item != "parent2")

            this.setState({value: filtValue});
            console.log("laskdfsdfsdfjslakfjdlsdfkj", filtValue);
    }

    render() {

        console.log("sldkfjsldkfjsldfkj",this.props.taskData);

        let { taskData } = this.props,
            success = taskData.getIn(['taskData', 'success']),
            progressType = taskData.getIn(['taskData', 'progressType']),
            finalData = taskData.getIn(['taskData', 'result']),
            {getFieldDecorator} = this.props.form;

        return (
            <div className='task'>
                <Form hideRequiredMark={true}>
                    <FormItem
                        label="选择分组">
                        {getFieldDecorator('groupName', {
                            rules: [{
                                required: true,
                                message: ' '
                            }]
                        })(
                            <TreeSelect
                                placeholder="请选择分组"
                                className="newTipsUpperGroup"
                                dropdownStyle={{maxHeight: 340, overflowX: 'hidden', overflowY: 'auto'}}
                                onChange={this.onChange.bind(this)}
                                treeDefaultExpandAll
                                multiple
                            >
                                <TreeNode value="parent2" title="parent 1-0" key="0-1-1" disabled={true}>
                                    <TreeNode value="leaf1" title="my leaf" key="random" />
                                    <TreeNode value="leaf2" title="your leaf" key="random1" />
                                </TreeNode>
                                <TreeNode value="parent3" title="parent 1-1" key="random2">
                                    <TreeNode value="sss" title={<b style={{ color: '#08c' }}>sss</b>} key="random3" />
                                </TreeNode>
                            </TreeSelect>
                        )}
                    </FormItem>
                </Form>
            </div>
        )
    }
}

Task = Form.create()(Task);

function mapStateToProps(state)
{

    return {
        taskData: state.getTaskDataReducer
    }
}

function mapDispatchToProps(dispatch)
{
    return bindActionCreators({getTaskData}, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Task)
