import React from "react";
import {Breadcrumb} from "antd";
class MainContentPage extends React.Component {
    constructor(props)
    {
        super(props);
    }
    render()
    {
        return <Breadcrumb></Breadcrumb>
    }
}