"use strict"

import React from 'react'
import {render} from 'react-dom'
import  'babel-polyfill'
import {Provider} from 'react-redux'
import CreateStoreModule from '../redux/store/createStoreModule'
import configStore from '../redux/store/createStore'
import App from '../framework/app/App.jsx'

const store = configStore();
render((
    <Provider store={store}>
        <App />
    </Provider>
), document.getElementById('yt-app'))
