import {combineReducers} from 'redux';
import {routerReducer} from 'react-router-redux';
import getTaskDataReducer from '../component/todaytask/rudex/taskReducer';

const rootReducer = combineReducers({
    routing: routerReducer,
    getTaskDataReducer
})

export default rootReducer;