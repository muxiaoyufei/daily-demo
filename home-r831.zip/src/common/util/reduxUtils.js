export function getAction(type, progressType, result, success)
{
    console.log("getAction type=", type, "progressType=", progressType, "result=", result);
    return {type,progressType, result, success}
}

export function getResultCode(jsonResult)
{
    return Promise.resolve(jsonResult.jsonResult);
}

export function dispatchAction(dispatch, type, progressType, success, result)
{
    dispatch(getAction(type, progressType,result, success,))
}