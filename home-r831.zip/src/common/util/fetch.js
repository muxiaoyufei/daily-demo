/* 
    *@param url string
*/
export function urlLoader(url, options = {})
{
    return fetch(url, options).then(jsonParse)
}

function jsonParse(res)
{
    return res.json()
	.then(jsonResult => ({...res, jsonResult}));
}